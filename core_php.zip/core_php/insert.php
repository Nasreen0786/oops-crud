<html>
<head>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>Insert Data Here</title>
	<link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Roboto|Varela+Round">
	<link rel="stylesheet" href="https://fonts.googleapis.com/icon?family=Material+Icons">
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
	<link rel="stylesheet" href="css/style.css">
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
	<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
	<style>
		#body{
			background-color:lightskyblue;
		}
		.form{
			height:310px;
			width:510px;
			/*border:2px solid black;*/
			margin:auto;
			background-color:powderblue;
		}
		.data{
			margin-left:10px;
		}
	</style>
</head>
<body id="body">
<h1 style="text-align:center;">Insert Data Here</h1>
	<form class="form" action="display.php" method="post" enctype="multipart/form-data">
		<div class="form-group">
			<label class="data">Name</label>
			<input type="text" class="form-control" name="name">
		</div>
		<div class="form=control">
			<label class="data">Email</label>
			<input type="email" class="form-control" name="email">
		</div>
		<div class="form-group">
			<label class="data">Phone Number</label>
			<input type="number" class="form-control" name=" phone_no">
		</div>
	
		<div class="form-group">
				<button type="submit" class="btn btn-primary" style="margin-left:10px;" name="save" value="save">Save
				</button>
		</div>
	</form>
</body>
</html>