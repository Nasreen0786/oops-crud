
<?php
include_once 'database.php';
if (isset($_POST['save'])) 
{
	
	$name=$_POST['name'];
		$sql="INSERT INTO `add`(`name`) VALUES ('$name')";
		if(mysqli_query($conn,$sql)){
		echo "inserted";
		}else{
			echo " not inserted";
		}
}
 $id=$_GET['id'];
        $sql=mysqli_query($conn,"DELETE FROM `add` WHERE id=$id" );

	$result=mysqli_query($conn,"SELECT * FROM `add` " );

	
?>
<html>
	<head>
		<title>File upload</title>
		<meta charset="utf-8">
		<meta name="viewport" content="width=device-width, initial-scale=1">
		<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">
		<link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.6.3/css/all.css" integrity="sha384-UHRtZLI+pbxtHCWp1t77Bi1L4ZtiqrqD80Kn4Z8NTSRyMA2Fd33n5dQ8lWUE00s/" crossorigin="anonymous"></head>
		<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
		<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
		<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js"></script>
		<script src="http://code.jquery.com/jquery-1.9.1.js"></script>
		<script type="text/javascript">
			$.ajax({
			  	url: "add.html",
			 	context: document.body
				}).done(function() {
			 	 $( this ).addClass( "done" );
			});
		</script>
  		<style>
  			#form{
			background-color:rgb(240, 255, 255);
			}
		.form{
			//border:2px solid black;
			height:400px;
			width:550px;
			margin:auto;
			background-color:rgb(240, 255, 255);
			margin-top:50px;
			}
 		</style>
	</head>
	<body  >
		<div class="container">
			<form id="addForm" action=""  method="post" >
			<div class="form-group">
				<label style="margin-left:10px;">Name</label>
				<input type="text" class="form-control" id="name" name="name" style="margin-top:10px;">
			</div>
			<div class="form-group">
				<button type="submit" id="save-button" class="btn btn-primary" style="margin-left:10px;" name="save">Save
				</button>
			</div>

<?php
	if(mysqli_num_rows($result)>0){
?>
			<table id="main" class="table table-bordered">
				<thead id="header">
					  <th scope="col">id</th>
				      <th scope="col">Name</th>
				      <th scope="col">Action</th>
				</thead>
<?php
	$i=1;
	while($row = mysqli_fetch_array($result)) {
?>
				<tbody id="table-form">
					<td><?php echo $i ?></td> 
					<td><?php echo $row['name']?></td>        	 
					<td><a href="?id=<?php echo $row['id']?>"><i class="fas fa-trash"></i></a>
					</td>
				</tbody>
<?php
	$i++;
		}
?>
			</table>
<?php
	}
?>
			</form>
		</div>
	</body>
</html>


