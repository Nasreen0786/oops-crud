<?php
include_once 'database.php';
if (isset($_POST['save'])) 
{
	$name = $_POST['name'];
	$email = $_POST['email'];
	$phone_no = $_POST['phone_no'];
	$sql="INSERT INTO `student_data`(`name`, `email`, `phone_no`) VALUES ('$name','$email','$phone_no')";
		-- $sql="INSERT INTO `add`(`name`) VALUES ('$name')";
		if(mysqli_query($conn,$sql)){
		echo "inserted";
		}else{
			echo " not inserted";
		}
}

	
?>